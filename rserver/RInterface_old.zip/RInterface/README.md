RInterface
==========

A R module with packaged functions to query the tranSMART database directly.