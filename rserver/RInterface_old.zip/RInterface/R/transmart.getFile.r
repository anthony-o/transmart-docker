transmart.getFile <- function(
  file.name    	= NA,
  file.path			= NA,
  config.file		= "~/RInterface.properties"
)
{
  require(RCurl)
  
  #Create the connection to the oracle DB.
  tranSMART.DB.connection <- tranSMART.DB.establishConnection()
  
  if(any(is.na(file.name))) stop("You must provide the file name.")
  
  query <- gsub("\n", " ", paste("select filestore_name, file_id
                                 from fmapp.fm_file 
                                 where display_name='", file.name, "'"
                                 ,sep="",collapse=","))
  
  if(!any(is.na(file.path))){
    folderFullName <- transmart.getFolderFullPath(file.path)
    pathQuery <- gsub("\n", " ", paste(" and file_id in 
                                       (select file_id from fmapp.FM_FOLDER_FILE_ASSOCIATION
                                       where folder_id in(
                                       select folder_id from fmapp.fm_folder
                                       where folder_full_name ='", folderFullName, "'))"
                                       ,sep="",collapse=",")) 
    query <- paste(query, pathQuery,sep="",collapse=",")
  }
  
  #Send the query to the server.
  rs <- dbSendQuery(tranSMART.DB.connection, query)
  
  print("Retrieving File.")
  
  #Retrieve the entire data set.
  fileResult <- fetch(rs)
  
  if(length(unique(fileResult$FILESTORE_NAME)) > 1)
  {
    print("Warning! Multiple files found.")
    fileResult$FILE_PATH <- lapply(fileResult$FILE_ID, tranSMART.DB.connection, FUN=transmart.getFolderPath)
    dataToReturn <- fileResult
  }
  else if(length(unique(fileResult$FILESTORE_NAME)) == 0)
  {
    print("Warning! No file found.")
  }else{
    #Clear the results object.
    dbClearResult(rs)
    
    #Disconnect from the database.
    dbDisconnect(tranSMART.DB.connection)  
    
    id <- fileResult$FILESTORE_NAME
    
    prop <- read.table(config.file, header=FALSE, sep="=", row.names=1, strip.white=TRUE, 
                       na.strings="NA", stringsAsFactors=FALSE)
    apiUrl <- prop['apiURL',]
    apiKey <- prop['apiKey',]
    
    url <-  paste(apiUrl, id, "/fsfile"
                  ,sep="",collapse=",")
    resp <- getURL(url, httpheader = c('apikey' = apiKey), ssl.verifypeer = FALSE)
    dataToReturn <- textConnection(resp)
  }
  dataToReturn
}

transmart.downloadFile<- function(
  file.name    	= NA,
  file.path			= NA,
  destination,
  config.file		= "~/RInterface.properties"
)
{
  #if the destination path is not given by the user, the destination variable is initialized.
  if(missing(destination)){
    
    filePath = paste(path.expand("~"),"/tmp-tranSMART",sep="")
    if(file.exists(filePath)==FALSE){
      dir.create(c(filePath))
    }
    destination = filePath
  }
  
  require(RCurl)
  
  #Create the connection to the oracle DB.
  tranSMART.DB.connection <- tranSMART.DB.establishConnection()
  
  if(any(is.na(file.name))) stop("You must provide the file name.")
  
  query <- gsub("\n", " ", paste("select filestore_name, file_id
                                 from fmapp.fm_file 
                                 where display_name='", file.name, "'"
                                 ,sep="",collapse=","))
  
  if(!any(is.na(file.path))){
    folderFullName <- transmart.getFolderFullPath(file.path)
    pathQuery <- gsub("\n", " ", paste(" and file_id in 
                                       (select file_id from fmapp.FM_FOLDER_FILE_ASSOCIATION
                                       where folder_id in(
                                       select folder_id from fmapp.fm_folder
                                       where folder_full_name ='", folderFullName, "'))"
                                       ,sep="",collapse=",")) 
    query <- paste(query, pathQuery,sep="",collapse=",")
  }
  
  #Send the query to the server.
  rs <- dbSendQuery(tranSMART.DB.connection, query)
  
  print("Retrieving File.")
  
  #Retrieve the entire data set.
  fileResult <- fetch(rs)
  
  if(length(unique(fileResult$FILESTORE_NAME)) > 1)
  {
    print("Warning! Multiple files found.")
    fileResult$FILE_PATH <- lapply(fileResult$FILE_ID, tranSMART.DB.connection, FUN=transmart.getFolderPath)
    dataToReturn <- fileResult
  }
  else if(length(unique(fileResult$FILESTORE_NAME)) == 0)
  {
    print("Warning! No file found.")
  }else{
    #Clear the results object.
    dbClearResult(rs)
    
    #Disconnect from the database.
    dbDisconnect(tranSMART.DB.connection)  
    
    id <- fileResult$FILESTORE_NAME
    
    prop <- read.table(config.file, header=FALSE, sep="=", row.names=1, strip.white=TRUE, 
                       na.strings="NA", stringsAsFactors=FALSE)
    apiUrl <- prop['apiURL',]
    apiKey <- prop['apiKey',]
    
    buf = binaryBuffer()
    
    url <-  paste(apiUrl, id, "/fsfile"
                  ,sep="",collapse=",")
    
    resp <- getURL(url, httpheader = c('apikey' = apiKey), ssl.verifypeer = FALSE,
                   write = getNativeSymbolInfo("R_curl_write_binary_data")$address, file =buf@ref)
    
    # Convert the internal data structure into an R raw vector
    b = as(buf, "raw")
    writeBin(b, paste(destination, "/", file.name, sep="")) #writing the raw vector under the destination  path + name
    dataToReturn <- paste(destination,"/",file.name, sep="")
    
  }
  dataToReturn
}

transmart.getFileList <- function(
  study.id      = NA
)
{
  if(any(is.na(study.id))) stop("You must provide the study identifier")
  
  tranSMART.DB.connection <- tranSMART.DB.establishConnection()
  
  #get the association folder id / folder name
  folderAssociation <- list()
  query <- "select folder_id, folder_name from FMAPP.FM_FOLDER"
  rs <- dbSendQuery(tranSMART.DB.connection, query)
  associationResult <- fetch(rs)
  dbClearResult(rs)
  for(i in 1:length(associationResult[,1])){
    folderAssociation[toString(associationResult[i,1])] = associationResult[i,2]
  }
  
  query <- gsub("\n", " ", paste("select f1.display_name, f1.file_id, f3.folder_full_name 
                                  from FMAPP.FM_FILE f1, FMAPP.FM_FOLDER_FILE_ASSOCIATION f2, FMAPP.FM_FOLDER f3
                                where f1.file_id in (
                                 select file_id from FMAPP.FM_FOLDER_FILE_ASSOCIATION where folder_id in(
                                 select folder_id from fmapp.fm_folder where folder_full_name like '%FOL:' ||
                                 (select folder_id from fmapp.FM_FOLDER_ASSOCIATION
                                 where object_uid in 
                                 (select unique_id from BIOMART.BIO_DATA_UID where bio_data_id in
                                 (select bio_experiment_id from BIOMART.BIO_EXPERIMENT where accession =UPPER('", study.id, "')))) || '\\%'))
                                  and f1.file_id = f2.file_id
                                  and f2.folder_id = f3.folder_id"
                                 ,sep="",collapse=","))
  
  rs <- dbSendQuery(tranSMART.DB.connection, query)
  
  #Retrieve the entire data set.
  fileResult <- fetch(rs)
  
  fileResult$FILE_PATH <- lapply(fileResult$FOLDER_FULL_NAME, FUN=transmart.getFolderPath, folderAssociation=folderAssociation)
  
  #Clear the results object.
  dbClearResult(rs)
  
  #Disconnect from the database.
  dbDisconnect(tranSMART.DB.connection)
  
  fileResult[c("DISPLAY_NAME", "FILE_ID", "FILE_PATH")]
}

transmart.getFolderPath <- function(
  file.id.path      = NA,
  folderAssociation   = NA
)
{
  folders <- unlist(strsplit(file.id.path, "\\\\"))
  
  path <- "\\"
  for(f in folders){
    if(f != ""){
      path <- paste(path, folderAssociation[[substr(f, 5, nchar(f))]], '\\', sep="",collapse=",")
    } 
  }
  path
}

transmart.getFolderFullPath <- function(
  file.path      = NA
)
{
  folders <- unlist(strsplit(file.path , "\\\\"))
  
  path <- "\\"
  parentId <- ""
  for(f in folders){
    if(f != ""){
      tranSMART.DB.connection <- tranSMART.DB.establishConnection()
      idQuery <- gsub("\n", " ", paste("select 'FOL:' || folder_id as folder_uid, folder_id
                                 from fmapp.fm_folder where folder_name = 
                                 '", f, "'"
                                       ,sep="",collapse=","))
      if(parentId != ""){
        parentQuery <- paste(" and parent_id = ", parentId,sep="",collapse=",")
        idQuery <- paste(idQuery, parentQuery,sep="",collapse=",")
      }
      rs <- dbSendQuery(tranSMART.DB.connection, idQuery)
      result <- fetch(rs)
      parentId <- result$FOLDER_ID
      path <- paste(path, result$FOLDER_UID, '\\', sep="",collapse=",")
    } 
  }
  path
}
